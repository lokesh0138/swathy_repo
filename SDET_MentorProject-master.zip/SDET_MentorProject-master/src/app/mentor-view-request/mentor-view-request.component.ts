import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-view-request',
  templateUrl: './mentor-view-request.component.html',
  styleUrls: ['./mentor-view-request.component.css']
})
export class MentorViewRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
