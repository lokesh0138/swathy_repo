export class Courses{
    constructor(public id:number,public course_name: string, public mentor_name: string, public desc:string, public mentor_image: String, public course_image: String){}
}