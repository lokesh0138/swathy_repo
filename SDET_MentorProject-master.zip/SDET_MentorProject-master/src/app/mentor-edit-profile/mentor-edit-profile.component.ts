import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-edit-profile',
  templateUrl: './mentor-edit-profile.component.html',
  styleUrls: ['./mentor-edit-profile.component.css']
})
export class MentorEditProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
